import React, { useState } from "react";
import github from "../assets/github.png";
import hamburgerIcon from "../assets/menus.png"; // Your hamburger icon image
import closeIcon from "../assets/close.png"; // Your close icon image
import { NavLink, useNavigate } from "react-router-dom";

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredSuggestions, setFilteredSuggestions] = useState([]);
  const navigate = useNavigate();

  const handleMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleCloseMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);

    if (value) {
      const filtered = cards.filter((card) =>
        card.title.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredSuggestions(filtered);
    } else {
      setFilteredSuggestions([]);
    }
  };

  const handleSuggestionClick = (path) => {
    setSearchTerm("");
    setFilteredSuggestions([]);
    navigate(`/components${path}`);
    handleCloseMenu();
  };

  const cards = [
    {
      icons: "🃏",
      title: "cards",
      to: "/cards",
      amount: 3,
    },
    {
      icons: "🔄",
      title: "Spinner",
      to: "/spinners",
      amount: 4,
    },
    {
      icons: "🦸🏻",
      title: "Hero Section",
      to: "/heros",
      amount: 2,
    },
    {
      icons: "🚨",
      title: "Alert",
      to: "/alerts",
      amount: 3,
    },
    {
      icons: "🔘",
      title: "Button",
      to: "/buttons",
      amount: 5,
    },
    {
      icons: "🤘🏻",
      title: "Navbar",
      to: "/navbars",
      amount: 5,
    },
    {
      icons: "🐾",
      title: "Footer",
      to: "/footers",
      amount: 6,
    },
    {
      icons: "🪜",
      title: "Accordian",
      to: "/accordians",
      amount: 2,
    },
  ];

  return (
    <nav className="relative flex justify-between items-center px-4 py-4 md:px-40 md:py-5 gradient-flow shadow-sm z-10">
      <div className="flex items-center gap-5">
        <div className="block lg:hidden">
          <img
            src={hamburgerIcon}
            alt="Menu"
            className="w-4 h-4 cursor-pointer"
            onClick={handleMenuToggle}
          />
        </div>
        <div className="flex items-center gap-8">
          <NavLink
            to={"/"}
            onClick={handleCloseMenu}
            className="text-xl font-semibold" // Logo styling remains unchanged
          >
            🔥 WindyUI
          </NavLink>
          <NavLink
            to={"/faq"}
            onClick={handleCloseMenu}
            className={({ isActive }) =>
              `text-gray-700 hidden md:flex font-thin hover:text-purple-500 cursor-pointer ${
                isActive ? "text-purple-500" : ""
              }`
            }
          >
            FAQ
          </NavLink>
          <a
            href="https://khair-me.vercel.app/"
            target="_blank"
            onClick={handleCloseMenu}
            className="text-gray-700 hidden md:flex font-thin hover:text-purple-500 cursor-pointer"
          >
            DEV
          </a>
          <NavLink
            to={"/lab"}
            onClick={handleCloseMenu}
            className={({ isActive }) =>
              `text-gray-700 hidden md:flex font-thin hover:text-purple-500 cursor-pointer ${
                isActive ? "text-purple-500" : ""
              }`
            }
          >
            PLAYGROUND
          </NavLink>
        </div>
      </div>

      <div className="flex items-center gap-7 hidden lg:flex relative">
        <input
          type="text"
          placeholder="search components"
          value={searchTerm}
          onChange={handleSearchChange}
          className="border border-gray-300 rounded-md px-3 py-1 focus:outline-none focus:ring-2 focus:ring-purple-300"
        />
        {filteredSuggestions.length > 0 && (
          <ul className="absolute top-full mt-2 left-0 bg-white shadow-lg rounded-md w-full z-30">
            {filteredSuggestions.map((suggestion, index) => (
              <li
                key={index}
                className="px-3 py-2 hover:bg-purple-100 cursor-pointer"
                onClick={() => handleSuggestionClick(suggestion.to)}
              >
                {suggestion.title}
              </li>
            ))}
          </ul>
        )}
        <div>
          <img src={github} alt="GitHub" className="w-8 h-8 cursor-pointer" />
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`lg:hidden fixed top-0 left-0 w-full bg-white shadow-md transition-transform transform ${
          isMobileMenuOpen ? "translate-y-0" : "-translate-y-full"
        } z-20`} // Ensure this has a higher z-index
      >
        <div className="flex flex-col p-5">
          {/* Close Button */}
          <div className="flex justify-end">
            <img
              src={closeIcon}
              alt="Close"
              className="w-4 h-4 cursor-pointer"
              onClick={handleCloseMenu}
            />
          </div>
          <NavLink
            to={"/"}
            onClick={handleCloseMenu}
            className="text-xl font-semibold mb-5" // Logo styling remains unchanged
          >
            🔥 WindyUI
          </NavLink>
          <NavLink
            to={"/faq"}
            onClick={handleCloseMenu}
            className={({ isActive }) =>
              `text-gray-700 font-thin mb-3 hover:text-purple-500 cursor-pointer ${
                isActive ? "text-purple-500" : ""
              }`
            }
          >
            FAQ
          </NavLink>
          <a
            href="https://khair-me.vercel.app/"
            onClick={handleCloseMenu}
            className="text-gray-700 font-thin mb-3 hover:text-purple-500 cursor-pointer"
          >
            DEV
          </a>
          <NavLink
            to={"/lab"}
            onClick={handleCloseMenu}
            className={({ isActive }) =>
              `text-gray-700 font-thin mb-3 hover:text-purple-500 cursor-pointer ${
                isActive ? "text-purple-500" : ""
              }`
            }
          >
            PLAYGROUND
          </NavLink>
          <div className="flex items-center gap-4 mt-5">
            <input
              type="text"
              placeholder="search components"
              value={searchTerm}
              onChange={handleSearchChange}
              className="border border-gray-300 rounded-md px-3 py-1 w-full focus:outline-none focus:ring-2 focus:ring-purple-300"
            />
            <div>
              <img
                src={github}
                alt="GitHub"
                className="w-8 h-8 cursor-pointer"
              />
            </div>
          </div>
          {filteredSuggestions.length > 0 && (
            <ul className="mt-2 bg-white shadow-lg rounded-md w-full z-30">
              {filteredSuggestions.map((suggestion, index) => (
                <li
                  key={index}
                  className="px-3 py-2 hover:bg-purple-100 cursor-pointer"
                  onClick={() => handleSuggestionClick(suggestion.to)}
                >
                  {suggestion.title}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
