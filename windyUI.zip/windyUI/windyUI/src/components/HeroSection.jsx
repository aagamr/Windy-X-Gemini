import React, { useState } from "react";
import { motion } from "framer-motion";
import attach from "../assets/attach-file.png";
import send from "../assets/send.png";
import { GoogleGenerativeAI } from "@google/generative-ai";
import gemini from "../assets/gemini.png";
const HeroSection = () => {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [activeTab, setActiveTab] = useState("preview");

  const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GOOGLE_API_KEY); // Replace with your actual API key

  const handleSubmit = async () => {
    if (prompt.trim() === "") {
      return;
    }

    try {
      setLoading(true);
      const alteredPrompt =
        "You are a Component generator which generates tailwind css componets, The Respose you will send should be just the code like if your response is ```html <button>Submit</button>``` then send the response just as <button>Submit</button> i.e without the (Backtick) or html or anything as a test, Give the styling as aesthetic or if not specified use the black(as background) and white(font text) theme and add animations using tailwind css only, try to use dummy images in source if there is an image tag so that it looks more good. The component you have to make is : " +
        prompt;
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });
      const result = await model.generateContent(alteredPrompt);
      const generatedText = result.response.text();

      setGeneratedContent(generatedText);
      setPrompt("");
      setLoading(false);
    } catch (error) {
      console.error("Error sending prompt to Gemini API:", error);
      setLoading(false);
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="w-full flex flex-col justify-center items-center text-center">
      <div className="w-full">
        <section className="flex flex-col lg:flex-col items-center justify-between bg-white md:p-8 rounded-lg">
          <div className="w-full lg:w-1/2 flex items-center justify-center mt-8 lg:mt-0">
            <motion.div
              className="w-24 h-24 lg:w-32 lg:h-32 border-4 border-purple-100 bg-purple-300 rounded-full flex items-center justify-center"
              initial={{ rotate: 0 }}
              animate={{ rotate: 360 }}
              transition={{
                duration: 1,
                repeat: Infinity,
                repeatType: "loop",
              }}
            >
              <span className="text-center text-xl lg:text-2xl text-white">
                {`>_<`}
              </span>
            </motion.div>
          </div>

          <div className="w-full lg:w-1/2 p-8">
            <motion.h1
              className="flex w-full gap-3 items-center justify-center text-2xl lg:text-3xl font-bold text-gray-900 mb-4"
              initial={{ opacity: 0, y: -50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              <h1> WindyUI</h1>
              <h1>X</h1>
              <img src={gemini} className="h-10 mb-5" />
            </motion.h1>

            <div className="w-full flex flex-col items-center">
              <motion.h2
                className="text-lg lg:text-xl text-gray-800 mb-4"
                initial={{ opacity: 0, y: -30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1 }}
              >
                Build your own components .
              </motion.h2>
              <div className="w-full max-w-2xl p-4 border-2 border-gray-300 rounded-lg bg-gray-50 shadow-lg">
                <input
                  type="text"
                  placeholder="Write a prompt..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="w-full p-3 bg-transparent border-none outline-none text-gray-700 text-lg"
                />
                <div className="flex justify-between items-center mt-4">
                  <button
                    disabled={true}
                    className="p-2 bg-purple-200 rounded-md hover:bg-purple-100 transition-colors duration-200"
                  >
                    <img src={attach} alt="Attach" className="w-6 h-6" />
                  </button>
                  <div className="flex items-center justify-center gap-3">
                    <span className="text-gray-600">{prompt.length} / 10</span>
                    <button
                      onClick={handleSubmit}
                      className={`flex items-center gap-2 p-3 ${
                        prompt.length < 10 ? "bg-gray-300" : "bg-gray-900"
                      } rounded-lg text-white  transition-colors duration-200`}
                      disabled={loading || prompt.length < 10}
                    >
                      {loading ? (
                        <>
                          <div role="status">
                            <svg
                              aria-hidden="true"
                              class="w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-white"
                              viewBox="0 0 100 101"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                fill="currentColor"
                              />
                              <path
                                d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                fill="currentFill"
                              />
                            </svg>
                            <span class="sr-only">Loading...</span>
                          </div>
                        </>
                      ) : (
                        <>
                          <p>Send</p>
                          <img src={send} alt="Send" className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {generatedContent && (
                <div className="w-full mt-8">
                  <div className="flex border-b mb-4">
                    <button
                      onClick={() => handleTabChange("preview")}
                      className={`py-2 px-4 text-sm font-medium ${
                        activeTab === "preview"
                          ? "border-b-2 border-blue-500 text-blue-600"
                          : "text-gray-600"
                      }`}
                    >
                      Preview
                    </button>
                    <button
                      onClick={() => handleTabChange("code")}
                      className={`py-2 px-4 text-sm font-medium ${
                        activeTab === "code"
                          ? "border-b-2 border-blue-500 text-blue-600"
                          : "text-gray-600"
                      }`}
                    >
                      Code
                    </button>
                  </div>

                  <div
                    className={`${
                      activeTab === "preview"
                        ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
                        : "p-0"
                    }`}
                  >
                    {activeTab === "preview" && (
                      <div
                        dangerouslySetInnerHTML={{ __html: generatedContent }}
                      />
                    )}
                    {activeTab === "code" && (
                      <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white item-start text-sm">
                        <code>{generatedContent}</code>
                      </pre>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default HeroSection;
