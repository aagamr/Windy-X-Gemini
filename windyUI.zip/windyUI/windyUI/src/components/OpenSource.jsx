import React from "react";

const OpenSource = () => {
  return (
    <div className="w-full bg-gray-50 py-2 justify-center flex border">
      <div className="font-thin text-sm">
        👋🏻 want to contribute to open source?{" "}
        <a
          href="https://github.com/yogeshvas/WindyUI-OpenSource"
          target="_blank"
          className="font-semibold"
        >
          click here
        </a>
      </div>
    </div>
  );
};

export default OpenSource;
