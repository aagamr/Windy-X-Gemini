import React from "react";

const Footer = () => {
  return (
    <footer className="py-6 bg-gray-50 border-t mt-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex flex-col items-center md:items-start justify-center">
            <span className="text-xl">🔥 Windy UI.</span>
            <p className="text-sm text-gray-600 ml-2">
              © 2024 All rights reserved.
            </p>
          </div>
          <p className="text-sm text-gray-500 mt-2 md:mt-0">
            Created by Yogesh Vashisth
          </p>
        </div>
        {/* <div className="mt-4 flex justify-center space-x-4">
          <a href="/privacy-policy" className="text-gray-600 hover:text-black">
            Privacy Policy
          </a>
          <a
            href="/terms-of-service"
            className="text-gray-600 hover:text-black"
          >
            Terms of Service
          </a>
        </div> */}
      </div>
    </footer>
  );
};

export default Footer;
