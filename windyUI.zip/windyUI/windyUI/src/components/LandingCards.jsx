import React from "react";
import { NavLink } from "react-router-dom";

const LandingCards = () => {
  const cards = [
    {
      icons: "🃏",
      title: "Cards",
      to: "/cards",
      amount: 3,
    },
    {
      icons: "🔄",
      title: "Spinners",
      to: "/spinners",
      amount: 4,
    },
    {
      icons: "🦸🏻",
      title: "Hero Sections",
      to: "/heros",
      amount: 2,
    },
    {
      icons: "🚨",
      title: "Alerts",
      to: "/alerts",
      amount: 3,
    },
    {
      icons: "🔘",
      title: "Buttons",
      to: "/buttons",
      amount: 5,
    },
    {
      icons: "🤘🏻",
      title: "Navbars",
      to: "/navbars",
      amount: 5,
    },
    {
      icons: "🐾",
      title: "Footers",
      to: "/footers",
      amount: 6,
    },
    {
      icons: "🪜",
      title: "Accordians",
      to: "/accordians",
      amount: 2,
    },
  ];

  return (
    <div className="px-4 md:px-60 ">
      <h2 className="text-2xl font-bold mb-6">Components</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {cards.map((item, index) => (
          <NavLink to={`/components${item.to}`}>
            <div
              key={index}
              className="bg-white border border-gray-300 shadow-md rounded-lg p-6 transform transition-transform hover:scale-105"
            >
              <div className="text-4xl mb-4">{item.icons}</div>
              <div className="text-lg font-semibold mb-2">{item.title}</div>
              <div className="text-sm text-gray-600 mb-4">
                {item.amount} component{item.amount > 1 ? "s" : ""}
              </div>
            </div>
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default LandingCards;
