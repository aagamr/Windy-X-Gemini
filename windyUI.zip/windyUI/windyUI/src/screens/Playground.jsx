import React, { useState } from "react";
import Editor from "@monaco-editor/react";
import { motion } from "framer-motion";

const Playground = () => {
  const [code, setCode] = useState(
    `<div class="max-w-md mx-auto text-center text-gray-900 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300 ease-in-out">
  <h2 class="text-4xl font-bold text-white mb-4">
    Welcome to WindyUI
  </h2>
  <p class="text-white text-opacity-90 mb-6">
    Elevate your projects with WindyUI’s stunning components. Designed to make your code look as sophisticated as it performs.
  </p>
  <button class="bg-white text-indigo-700 px-6 py-3 rounded-full font-medium shadow-md hover:bg-indigo-50 transition-all duration-200">
    Start Creating
  </button>
</div>
`
  );

  const handleEditorChange = (value) => {
    setCode(value);
  };

  const handleEditorDidMount = (editor) => {
    // Adding custom action for "Custom Action"
    editor.addAction({
      id: "my-custom-action",
      label: "Custom Action",
      keybindings: [
        monaco.KeyMod.CtrlCmd | monaco.KeyCode.KEY_K, // Example: Ctrl/Cmd+K
      ],
      contextMenuGroupId: "navigation",
      contextMenuOrder: 1.5,
      run: () => {
        alert("Custom action triggered!");
      },
    });
  };

  return (
    <div className="flex flex-col md:flex-row h-[80vh] bg-gray-100">
      {/* Editor Section */}
      <div className="md:w-1/2 w-full flex flex-col border-b md:border-b-0 md:border-r border-gray-300">
        <div className="p-3 bg-gray-600 text-center text-lg font-bold text-white">
          Code Editor
        </div>
        <div className="flex-1">
          <Editor
            height="100%" // Maintain full height of the flex container
            defaultLanguage="html"
            value={code}
            theme="vs-dark"
            onChange={handleEditorChange}
            onMount={handleEditorDidMount}
            options={{
              fontSize: 16,
              wordWrap: "on",
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
            }}
          />
        </div>
      </div>

      {/* Preview Section */}
      <div className="md:w-1/2 w-full flex flex-col">
        <div className="p-3 bg-gray-600 text-center text-lg font-bold text-white">
          Live Preview
        </div>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex-1 bg-white p-6 flex justify-center items-center"
        >
          <div className="w-full h-full border border-gray-300 rounded-lg shadow-lg overflow-hidden">
            <iframe
              className="w-full h-full border-none"
              srcDoc={`<!DOCTYPE html>
              <html lang="en">
              <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
              </head>
              <body class="font-sans bg-gray-100">
                ${code}
              </body>
              </html>`}
            ></iframe>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Playground;
