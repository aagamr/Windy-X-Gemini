import React from "react";
import OpenSource from "../components/OpenSource";
import HeroSection from "../components/HeroSection";
import LandingCards from "../components/LandingCards";

const Landing = () => {
  return (
    <div>
      <OpenSource />
      <HeroSection />
      <LandingCards />
    </div>
  );
};

export default Landing;
