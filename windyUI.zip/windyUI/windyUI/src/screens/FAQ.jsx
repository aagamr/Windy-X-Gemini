import React from "react";
import { motion } from "framer-motion";

const FAQ = () => {
  const faqs = [
    {
      question: "What is WindyUI?",
      answer:
        "WindyUI is a collection of stylish and customizable components designed to enhance your projects with minimal effort.",
    },
    {
      question: "How can I use WindyUI?",
      answer:
        "Simply browse our collection, choose the components you like, and integrate them into your project using Tailwind CSS.",
    },
    {
      question: "Is WindyUI free to use?",
      answer: "Yes, WindyUI is open-source and free to use in your projects.",
    },
    {
      question: "Does WindyUI support dark mode?",
      answer:
        "Yes, WindyUI is built with Tailwind CSS, making it easy to toggle between light and dark modes.",
    },
    {
      question: "Can I contribute to WindyUI?",
      answer:
        "Absolutely! WindyUI is open-source, and contributions are welcome. Feel free to submit issues or pull requests on GitHub.",
    },
    {
      question: "Is WindyUI suitable for large-scale projects?",
      answer:
        "Yes, WindyUI's components are designed to be scalable and customizable, making them ideal for both small and large-scale projects.",
    },
  ];

  return (
    <div className="w-full flex flex-col justify-center items-center p-8">
      <div className="w-full max-w-7xl p-2">
        <section className="flex flex-col items-start bg-white md:p-8 rounded-lg">
          <motion.h1
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-8"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            Frequently Asked Questions
          </motion.h1>

          <div className="w-full max-w-4xl">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                className="p-4 mb-4 border-b border-gray-200"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <h2 className="text-lg font-semibold text-gray-800">
                  {faq.question}
                </h2>
                <p className="text-base text-gray-600 mt-2">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default FAQ;
