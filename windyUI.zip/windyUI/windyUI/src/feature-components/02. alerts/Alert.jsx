import React, { useEffect } from "react";
import Alert01 from "./components/Alert01";
import Alert02 from "./components/Alert02";
import Alert03 from "./components/Alert03";

const Alert = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Alerts.</div>

      <Alert02 />
      <Alert01 />
      <Alert03 />
    </div>
  );
};

export default Alert;
