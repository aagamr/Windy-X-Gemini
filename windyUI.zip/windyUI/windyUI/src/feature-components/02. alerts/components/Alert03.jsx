import React, { useState } from "react";
import { motion } from "framer-motion"; // Importing framer-motion for animation

const Alert03 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div className="flex justify-center p-4">
            <motion.div
              className={
                "p-4 rounded shadow-lg bg-blue-100 text-blue-800 flex items-center space-x-4"
              }
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex-1">Connecting to database...</div>
              {/* <button className="text-lg font-semibold">&times;</button> */}
            </motion.div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`//requirments: npm install framer-motion
              
  <motion.div
  className="p-4 rounded shadow-lg bg-blue-100 text-blue-800 flex items-center justify-between space-x-4"
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  exit={{ opacity: 0, y: 20 }}
  transition={{ duration: 0.3 }}
>
  <div className="flex-1">Connecting to database...</div>
  <button className="text-lg font-semibold" onClick={() => {/* Handle close button click */}}>&times;</button>
</motion.div>

`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Alert03;
