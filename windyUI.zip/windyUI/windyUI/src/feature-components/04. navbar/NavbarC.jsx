import React, { useEffect } from "react";
import Navbar01 from "./components/Navbar01";
import Navbar02 from "./components/Navbar02";
import Navbar03 from "./components/Navbar03";
import Navbar04 from "./components/Navbar04";
import Navbar05 from "./components/Navbar05";

const NavbarC = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Navbar.</div>
      <Navbar01 />
      <Navbar02 />
      <Navbar03 />
      <Navbar04 />
      <Navbar05 />
    </div>
  );
};

export default NavbarC;
