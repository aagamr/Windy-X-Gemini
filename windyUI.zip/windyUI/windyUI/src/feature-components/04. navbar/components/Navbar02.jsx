import React, { useState } from "react";

// Sample image URL for demonstration
const imageUrl = "https://via.placeholder.com/150";

const Navbar02 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div role="status" className="flex flex-col w-full">
            <nav class="bg-white shadow-md px-10 py-5 rounded-lg">
              <div class="container mx-auto px-4 py-2 flex justify-between items-center">
                <a href="#" class="text-2xl font-semibold text-gray-800 ">
                  WindyUI
                </a>

                <div class="hidden md:flex space-x-8">
                  <a
                    href="#"
                    class="text-gray-600 hover:text-gray-900 transition duration-300"
                  >
                    Home
                  </a>
                  <a
                    href="#"
                    class="text-gray-600 hover:text-gray-900 transition duration-300"
                  >
                    Portfolio
                  </a>
                  <a
                    href="#"
                    class="text-gray-600 hover:text-gray-900 transition duration-300"
                  >
                    Blog
                  </a>
                  <a
                    href="#"
                    class="text-gray-600 hover:text-gray-900 transition duration-300"
                  >
                    Contact
                  </a>
                </div>

                <div class="hidden md:block">
                  <a
                    href="#"
                    class="px-4 py-2 bg-blue-600 text-white rounded-md shadow-md hover:bg-blue-700 transition duration-300"
                  >
                    Get Started
                  </a>
                </div>

                <div class="md:hidden flex items-center">
                  <button
                    id="mobile-menu-btn"
                    class="text-gray-800 focus:outline-none"
                  >
                    <svg
                      class="w-6 h-6"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4 6h16M4 12h16m-7 6h7"
                      ></path>
                    </svg>
                  </button>
                </div>
              </div>

              <div id="mobile-menu" class="hidden md:hidden bg-white shadow-md">
                <a
                  href="#"
                  class="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
                >
                  Home
                </a>
                <a
                  href="#"
                  class="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
                >
                  Portfolio
                </a>
                <a
                  href="#"
                  class="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
                >
                  Blog
                </a>
                <a
                  href="#"
                  class="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
                >
                  Contact
                </a>
                <a
                  href="#"
                  class="block px-4 py-2 mt-2 bg-blue-600 text-white text-center rounded-md shadow-md hover:bg-blue-700 transition duration-300"
                >
                  Get Started
                </a>
              </div>
            </nav>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div role="status" className="flex flex-col w-full">
  <nav className="bg-white shadow-md px-10 py-5 rounded-lg">
    <div className="container mx-auto px-4 py-2 flex justify-between items-center">
      <a href="#" className="text-2xl font-semibold text-gray-800">
        WindyUI
      </a>

      <div className="hidden md:flex space-x-8">
        <a
          href="#"
          className="text-gray-600 hover:text-gray-900 transition duration-300"
        >
          Home
        </a>
        <a
          href="#"
          className="text-gray-600 hover:text-gray-900 transition duration-300"
        >
          Portfolio
        </a>
        <a
          href="#"
          className="text-gray-600 hover:text-gray-900 transition duration-300"
        >
          Blog
        </a>
        <a
          href="#"
          className="text-gray-600 hover:text-gray-900 transition duration-300"
        >
          Contact
        </a>
      </div>

      <div className="hidden md:block">
        <a
          href="#"
          className="px-4 py-2 bg-blue-600 text-white rounded-md shadow-md hover:bg-blue-700 transition duration-300"
        >
          Get Started
        </a>
      </div>

      <div className="md:hidden flex items-center">
        <button
          id="mobile-menu-btn"
          className="text-gray-800 focus:outline-none"
          onClick={() => {
            const menu = document.getElementById("mobile-menu");
            menu.classList.toggle("hidden");
          }}
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M4 6h16M4 12h16m-7 6h7"
            ></path>
          </svg>
        </button>
      </div>
    </div>

    <div
      id="mobile-menu"
      className="hidden md:hidden bg-white shadow-md mt-4 rounded-lg"
    >
      <a
        href="#"
        className="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
      >
        Home
      </a>
      <a
        href="#"
        className="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
      >
        Portfolio
      </a>
      <a
        href="#"
        className="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
      >
        Blog
      </a>
      <a
        href="#"
        className="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition duration-300"
      >
        Contact
      </a>
      <a
        href="#"
        className="block px-4 py-2 mt-2 bg-blue-600 text-white text-center rounded-md shadow-md hover:bg-blue-700 transition duration-300"
      >
        Get Started
      </a>
    </div>
  </nav>
</div>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Navbar02;
