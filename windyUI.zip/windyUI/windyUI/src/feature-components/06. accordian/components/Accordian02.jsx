import React, { useState } from "react";
import { ChevronDownIcon } from "@heroicons/react/solid";
import { Disclosure } from "@headlessui/react";

const Accordian02 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div role="status" className="flex flex-col w-full">
            <div className="w-full max-w-lg p-4 mx-auto bg-gray-50 rounded-xl shadow-lg">
              {["Section 1", "Section 2", "Section 3"].map((title, index) => (
                <Disclosure key={index}>
                  {({ open }) => (
                    <>
                      <Disclosure.Button className="flex items-center justify-between w-full px-6 py-3 text-lg font-semibold text-left text-gray-800 bg-gray-200 border-l-4 border-indigo-500 rounded-lg hover:bg-gray-300 focus:outline-none focus-visible:ring focus-visible:ring-indigo-500 focus-visible:ring-opacity-75 mb-2">
                        <span>{title}</span>
                        <ChevronDownIcon
                          className={`${
                            open ? "transform rotate-180" : ""
                          } w-6 h-6 text-indigo-600`}
                        />
                      </Disclosure.Button>
                      <Disclosure.Panel className="px-6 pt-4 pb-3 text-base text-gray-700">
                        Detailed content for {title} goes here. Customize this
                        section as needed.
                      </Disclosure.Panel>
                    </>
                  )}
                </Disclosure>
              ))}
            </div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`// requirments : npm i @heroicons/react@v1 npm i @heroicons/react@v1 
                
//imports 👇🏻
import { ChevronDownIcon } from "@heroicons/react/solid";
import { Disclosure } from "@headlessui/react";
              
<div role="status" className="flex flex-col w-full">
  <div className="w-full max-w-lg p-4 mx-auto bg-gray-50 rounded-xl shadow-lg">
    {["Section 1", "Section 2", "Section 3"].map((title, index) => (
      <Disclosure key={index}>
        {({ open }) => (
          <>
            <Disclosure.Button className="flex items-center justify-between w-full px-6 py-3 text-lg font-semibold text-left text-gray-800 bg-gray-200 border-l-4 border-indigo-500 rounded-lg hover:bg-gray-300 focus:outline-none focus-visible:ring focus-visible:ring-indigo-500 focus-visible:ring-opacity-75 mb-2">
              <span>{title}</span>
              <ChevronDownIcon
                className={\`\${open ? "transform rotate-180" : ""} w-6 h-6 text-indigo-600\`}
              />
            </Disclosure.Button>
            <Disclosure.Panel className="px-6 pt-4 pb-3 text-base text-gray-700">
              Detailed content for {title} goes here. Customize this
              section as needed.
            </Disclosure.Panel>
          </>
        ))}
      </Disclosure>
    ))}
  </div>
</div>`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Accordian02;
