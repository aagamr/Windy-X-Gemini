import React, { useState } from "react";
import { ChevronUpIcon } from "@heroicons/react/solid";
import { Disclosure } from "@headlessui/react";

// Sample image URL for demonstration
const imageUrl = "https://via.placeholder.com/150";

const Accordian01 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div role="status" className="flex flex-col w-full">
            <div className="w-full max-w-md p-2 mx-auto bg-white rounded-2xl">
              {["Row 1", "Row 2", "Row 3"].map((title, index) => (
                <Disclosure key={index}>
                  {({ open }) => (
                    <>
                      <Disclosure.Button className="flex justify-between w-full px-4 py-2 text-sm font-medium text-left text-blue-900 bg-blue-100 rounded-lg hover:bg-blue-200 focus:outline-none focus-visible:ring focus-visible:ring-blue-500 focus-visible:ring-opacity-75 mb-2">
                        <span>{title}</span>
                        <ChevronUpIcon
                          className={`${
                            open ? "transform rotate-180" : ""
                          } w-5 h-5 text-blue-500`}
                        />
                      </Disclosure.Button>
                      <Disclosure.Panel className="px-4 pt-4 pb-2 text-sm text-gray-500">
                        Content for {title}
                      </Disclosure.Panel>
                    </>
                  )}
                </Disclosure>
              ))}
            </div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`// requirments : npm i @heroicons/react@v1 npm i @heroicons/react@v1 
                
//imports 👇🏻
import { ChevronDownIcon } from "@heroicons/react/solid";
import { Disclosure } from "@headlessui/react";
              

<div role="status" className="flex flex-col items-center w-full">
  <div className="w-full max-w-md p-4 bg-white rounded-2xl shadow-lg">
    {["Row 1", "Row 2", "Row 3"].map((title, index) => (
      <Disclosure key={index}>
        {({ open }) => (
          <>
            <Disclosure.Button className="flex justify-between items-center w-full px-4 py-3 text-sm font-medium text-left text-blue-900 bg-blue-100 rounded-lg hover:bg-blue-200 focus:outline-none focus-visible:ring focus-visible:ring-blue-500 focus-visible:ring-opacity-75 mb-3">
              <span>{title}</span>
              <ChevronUpIcon
                className={\`\${open ? "transform rotate-180" : ""} w-5 h-5 text-blue-500\`}
              />
            </Disclosure.Button>
            <Disclosure.Panel className="px-4 pt-2 pb-3 text-sm text-gray-500">
              Content for {title}
            </Disclosure.Panel>
          </>
        ))}
      </Disclosure>
    ))}
  </div>
</div>`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Accordian01;
