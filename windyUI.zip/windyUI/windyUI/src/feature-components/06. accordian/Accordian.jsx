import React, { useEffect } from "react";
import Accordian01 from "./components/Accordian01";
import Accordian02 from "./components/Accordian02";

const Accordian = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Accordian.</div>
      <Accordian01 />
      <Accordian02 />
    </div>
  );
};

export default Accordian;
