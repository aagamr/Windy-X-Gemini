import React, { useEffect } from "react";
import Hero1 from "./components/Hero1";
import Hero2 from "./components/Hero2";

const HeroSectionC = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Hero Section.</div>
      <Hero1 />
      <Hero2 />
    </div>
  );
};

export default HeroSectionC;
