import React, { useState } from "react";
import { motion } from "framer-motion";
// Sample image URL for demonstration

const Hero2 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50  flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div className="flex justify-center p-4 w-full">
            <section className="flex flex-col lg:flex-row items-center justify-between bg-white p-8 rounded-lg">
              {/* Left Side */}
              <div className="w-full lg:w-1/2 p-8">
                <motion.h1
                  className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 1 }}
                >
                  WindyUI
                </motion.h1>
                <motion.p
                  className="text-base lg:text-sm text-gray-700"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 1, delay: 0.2 }}
                >
                  We’ve got you covered with all the components you need for
                  faster development.
                </motion.p>
              </div>

              {/* Right Side */}
              <div className="w-full lg:w-1/2 flex items-center justify-center mt-8 lg:mt-0">
                <motion.div
                  className="w-24 h-24 lg:w-32 lg:h-32 border-4 border-gray-100 bg-blue-300 rounded-full flex items-center justify-center"
                  initial={{ rotate: 0 }}
                  animate={{ rotate: 360 }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    repeatType: "loop",
                  }}
                >
                  <span className="text-center text-xl lg:text-2xl text-white">
                    +_+
                  </span>
                </motion.div>
              </div>
            </section>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div className="flex justify-center w-full p-4">
  <div className="bg-black flex flex-col items-center justify-center w-full max-w-xl p-10 rounded-lg">
    <div className="text-center px-4 md:px-8">
      <h1 className="text-3xl md:text-3xl font-bold text-white mb-4">
        Welcome to WindyUI!
      </h1>
      <p className="text-lg text-gray-200 mb-8">
        Discover amazing content and explore new ideas.
      </p>
      <div className="flex justify-center space-x-4">
        <a
          href="#get-started"
          className="bg-white text-black px-6 py-3 rounded-lg font-semibold hover:bg-gray-100"
        >
          Get Started
        </a>
        <a
          href="#learn-more"
          className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-500"
        >
          Learn More
        </a>
      </div>
    </div>
  </div>
</div>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Hero2;
