import React, { useState } from "react";

// Sample image URL for demonstration

const Hero1 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50  flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div className="flex justify-center p-4 w-full">
            <div class="bg-gray-700  flex items-center justify-center w-full p-10 rounded-lg">
              <div class="text-center px-4 md:px-8">
                <h1 class="text-3xl md:text-3xl font-bold text-white mb-4">
                  Welcome to WindyUI!
                </h1>
                <p class="text-lg md:text- text-gray-200 mb-8">
                  Discover amazing content and explore new ideas.
                </p>
                <div class="flex justify-center space-x-4">
                  <a
                    href="#get-started"
                    class="bg-white text-black px-6 py-3 rounded-lg font-semibold hover:bg-gray-100"
                  >
                    Get Started
                  </a>
                  <a
                    href="#learn-more"
                    class="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-500"
                  >
                    Learn More
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div className="flex justify-center w-full p-4">
  <div className="bg-gray-700 flex flex-col items-center justify-center w-full max-w-xl p-10 rounded-lg">
    <div className="text-center px-4 md:px-8">
      <h1 className="text-3xl md:text-3xl font-bold text-white mb-4">
        Welcome to WindyUI!
      </h1>
      <p className="text-lg text-gray-200 mb-8">
        Discover amazing content and explore new ideas.
      </p>
      <div className="flex justify-center space-x-4">
        <a
          href="#get-started"
          className="bg-white text-black px-6 py-3 rounded-lg font-semibold hover:bg-gray-100"
        >
          Get Started
        </a>
        <a
          href="#learn-more"
          className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-500"
        >
          Learn More
        </a>
      </div>
    </div>
  </div>
</div>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Hero1;
