import React, { useEffect } from "react";
import Card1 from "./components/Card1";
import Card2 from "./components/Card2";
import Card3 from "./components/Card3";

const Cards = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Cards.</div>
      <Card1 />
      <Card2 />
      <Card3 />
    </div>
  );
};

export default Cards;
