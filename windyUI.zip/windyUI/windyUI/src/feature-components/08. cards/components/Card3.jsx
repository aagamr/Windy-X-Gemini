import React, { useState } from "react";
import { motion } from "framer-motion";
// Sample image URL for demonstration

const Card3 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50  flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <aside class="bg-black text-white p-6 rounded-lg w-full max-w-lg font-mono">
            <div class="flex justify-between items-center">
              <div class="flex space-x-2 text-red-500">
                <div class="w-3 h-3 rounded-full bg-red-500"></div>
                <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div class="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <p class="text-sm">bash</p>
            </div>
            <div class="mt-4">
              <p class="text-green-400">$ npm install next</p>
              <p class="text-white">+ next@10.2.3</p>
              <p class="text-white">
                added 1 package, and audited 2 packages in 3s
              </p>
              <p class="text-green-400">$</p>
            </div>
          </aside>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<aside class="bg-black text-white p-6 rounded-lg w-full max-w-lg font-mono">
  <div class="flex justify-between items-center">
    <div class="flex space-x-2 text-red-500">
      <div class="w-3 h-3 rounded-full bg-red-500"></div>
      <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
      <div class="w-3 h-3 rounded-full bg-green-500"></div>
    </div>
    <p class="text-sm">bash</p>
  </div>
  <div class="mt-4">
    <p class="text-green-400">$ npm install next</p>
    <p class="text-white">+ next@10.2.3</p>
    <p class="text-white">added 1 package, and audited 2 packages in 3s</p>
    <p class="text-green-400">$</p>
  </div>
</aside>


`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Card3;
