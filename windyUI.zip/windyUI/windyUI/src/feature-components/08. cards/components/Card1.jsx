import React, { useState } from "react";

// Sample image URL for demonstration

const Card1 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50  flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div class="flex flex-col bg-white rounded-3xl">
            <div class="px-6 py-8 sm:p-10 sm:pb-6">
              <div class="grid items-center justify-center w-full grid-cols-1 text-left">
                <div>
                  <h2 class="text-lg font-medium tracking-tighter text-gray-600 lg:text-3xl">
                    Starter
                  </h2>
                  <p class="mt-2 text-sm text-gray-500">
                    Suitable to grow steadily.
                  </p>
                </div>
                <div class="mt-6">
                  <p>
                    <span class="text-5xl font-light tracking-tight text-black">
                      $25
                    </span>
                    <span class="text-base font-medium text-gray-500">
                      {" "}
                      /mo{" "}
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <div class="flex px-6 pb-8 sm:px-8">
              <a
                aria-describedby="tier-company"
                class="flex items-center justify-center w-full px-6 py-2.5 text-center text-white duration-200 bg-black border-2 border-black rounded-full nline-flex hover:bg-transparent hover:border-black hover:text-black focus:outline-none focus-visible:outline-black text-sm focus-visible:ring-black"
                href="#"
              >
                Get started
              </a>
            </div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div class="flex flex-col bg-white rounded-3xl">
  <div class="px-6 py-8 sm:p-10 sm:pb-6">
    <div class="grid items-center justify-center w-full grid-cols-1 text-left">
      <div>
        <h2
          class="text-lg font-medium tracking-tighter text-gray-600 lg:text-3xl"
        >
          Starter
        </h2>
        <p class="mt-2 text-sm text-gray-500">Suitable to grow steadily.</p>
      </div>
      <div class="mt-6">
        <p>
          <span class="text-5xl font-light tracking-tight text-black">
            $25
          </span>
          <span class="text-base font-medium text-gray-500"> /mo </span>
        </p>
      </div>
    </div>
  </div>
  <div class="flex px-6 pb-8 sm:px-8">
    <a
      aria-describedby="tier-company"
      class="flex items-center justify-center w-full px-6 py-2.5 text-center text-white duration-200 bg-black border-2 border-black rounded-full nline-flex hover:bg-transparent hover:border-black hover:text-black focus:outline-none focus-visible:outline-black text-sm focus-visible:ring-black"
      href="#"
    >
      Get started
    </a>
  </div>
</div>

`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Card1;
