import React, { useState } from "react";
import { motion } from "framer-motion";
// Sample image URL for demonstration

const Card2 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50  flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div class="relative drop-shadow-xl w-48 h-64 overflow-hidden rounded-xl bg-[#3d3c3d]">
            <div class="absolute flex items-center justify-center text-white z-[1] opacity-90 rounded-xl inset-0.5 bg-[#323132]">
              CARD
            </div>
            <div class="absolute w-56 h-48 bg-white blur-[50px] -left-1/2 -top-1/2"></div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div
  class="relative drop-shadow-xl w-48 h-64 overflow-hidden rounded-xl bg-[#3d3c3d]"
>
  <div
    class="absolute flex items-center justify-center text-white z-[1] opacity-90 rounded-xl inset-0.5 bg-[#323132]"
  >
    CARD
  </div>
  <div class="absolute w-56 h-48 bg-white blur-[50px] -left-1/2 -top-1/2"></div>
</div>

`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Card2;
