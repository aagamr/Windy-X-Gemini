import React, { useState } from "react";

// Sample image URL for demonstration
const imageUrl = "https://via.placeholder.com/150";

const Spinner04 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 items-center justify-center flex  min-h-40 "
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div
            role="status"
            className="flex flex-col justify-center items-center  "
          >
            <div class="rounded-md h-12 w-12 border-4 border-t-4 border-blue-500 animate-spin absolute"></div>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div class="rounded-md h-12 w-12 border-4 border-t-4 border-blue-500 animate-spin absolute"></div>`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Spinner04;
