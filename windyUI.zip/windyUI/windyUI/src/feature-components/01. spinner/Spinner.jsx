import React, { useEffect } from "react";
import Spinner01 from "./components/Spinner01";
import Spinner02 from "./components/Spinner02";
import Spinner03 from "./components/Spinner03";
import Spinner04 from "./components/Spinner04";

const Spinner = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Spinners</div>

      <Spinner02 />
      <Spinner03 />
      <Spinner04 />
      <Spinner01 />
    </div>
  );
};

export default Spinner;
