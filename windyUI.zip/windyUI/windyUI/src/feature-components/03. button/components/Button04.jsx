import React, { useState } from "react";
import { motion } from "framer-motion"; // Importing framer-motion for animation

const Button04 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div className="flex justify-center p-4">
            <motion.button
              className="flex items-center px-6 py-3 font-semibold text-white bg-black rounded-lg shadow-md transition-transform duration-300 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-white gap-2"
              whileHover={{ gap: 8 }} // Adjust the gap value here
              whileTap={{ scale: 0.1 }}
            >
              <motion.span className="mr-1">Explore</motion.span>
              <motion.span>
                <svg
                  className="w-5 h-5"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 7l5 5m0 0l-5 5m5-5H3"
                  />
                </svg>
              </motion.span>
            </motion.button>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`// requirements: npm install framer-motion

<motion.button
      className="px-6 py-3 font-semibold text-white bg-gradient-to-r from-green-400 to-teal-500 rounded-lg shadow-lg transform transition-transform duration-300 hover:from-green-500 hover:to-teal-600 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-green-300"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
>
      Click Me
</motion.button>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Button04;
