import React from "react";
import Button01 from "./components/Button01";
import Button02 from "./components/Button02";
import Button03 from "./components/Button03";
import Button04 from "./components/Button04";
import Button05 from "./components/Button05";
import Button06 from "./components/Button06";
import { useEffect } from "react";

const Button = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Buttons.</div>
      <Button01 />
      <Button02 />
      <Button03 />
      <Button04 />
      <Button05 />
      <Button06 />
    </div>
  );
};

export default Button;
