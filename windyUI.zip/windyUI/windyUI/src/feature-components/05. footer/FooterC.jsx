import React, { useEffect } from "react";
import Footer01 from "./components/Footer01";
import Footer02 from "./components/Footer02";
import Footer03 from "./components/Footer03";
import Footer04 from "./components/Footer04";
import Footer05 from "./components/Footer05";

const FooterC = () => {
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  }, []);
  return (
    <div className="p-5 md:px-40 md:py-10">
      <div className="text-2xl font-bold">Footer.</div>
      <Footer01 />
      <Footer02 />
      <Footer03 />
      <Footer04 />
      <Footer05 />
    </div>
  );
};

export default FooterC;
