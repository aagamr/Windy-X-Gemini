import React, { useState } from "react";

// Sample image URL for demonstration
const imageUrl = "https://via.placeholder.com/150";

const Footer02 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div role="status" className="flex flex-col w-full">
            <footer class="bg-blue-500 text-white py-8 rounded-lg">
              <div class="container mx-auto px-6">
                <div class="flex flex-col md:flex-row md:justify-between items-center">
                  <div class="mb-6 md:mb-0 text-center md:text-left">
                    <h2 class="text-xl font-semibold mb-2">WindyUI</h2>

                    <p class="text-gray-100">
                      We provide top-notch services to help you achieve your
                      goals.
                    </p>
                  </div>

                  <div class="mb-6 md:mb-0">
                    <h2 class="text-xl font-semibold mb-2 text-center md:text-left">
                      Quick Links
                    </h2>
                    <ul class="space-y-2">
                      <li>
                        <a href="#" class="text-gray-100 hover:text-white">
                          Home
                        </a>
                      </li>
                      <li>
                        <a href="#" class="text-gray-100 hover:text-white">
                          Services
                        </a>
                      </li>
                      <li>
                        <a href="#" class="text-gray-100 hover:text-white">
                          Pricing
                        </a>
                      </li>
                      <li>
                        <a href="#" class="text-gray-100 hover:text-white">
                          Contact
                        </a>
                      </li>
                    </ul>
                  </div>

                  <div class="text-center md:text-right">
                    <h2 class="text-xl font-semibold mb-2">Contact Us</h2>
                    <p class="text-gray-100">1234 Main Street, Anytown, USA</p>
                    <p class="text-gray-100">Phone: (123) 456-7890</p>
                    <p class="text-gray-100">Email: writetokhair@gmail.com</p>
                  </div>
                </div>

                <div class="mt-8 border-t border-gray-100 pt-4 text-center md:text-left">
                  <div class="flex justify-center md:justify-start space-x-4 mb-4">
                    <a href="#" class="text-gray-100 hover:text-white">
                      Facebook
                    </a>
                    <a href="#" class="text-gray-100 hover:text-white">
                      Twitter
                    </a>
                    <a href="#" class="text-gray-100 hover:text-white">
                      LinkedIn
                    </a>
                    <a href="#" class="text-gray-100 hover:text-white">
                      Instagram
                    </a>
                  </div>
                  <p class="text-sm text-gray-200">
                    © 2024 YourCompany. All rights reserved.
                  </p>
                </div>
              </div>
            </footer>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div role="status" className="flex flex-col w-full">
  <footer className="bg-blue-900 text-white py-8 rounded-lg">
    <div className="container mx-auto px-6">
      <div className="flex flex-col md:flex-row md:justify-between items-start md:items-center">
        {/* About Section */}
        <div className="mb-6 md:mb-0 text-center md:text-left">
          <h2 className="text-xl font-semibold mb-2">WindyUI</h2>
          <p className="text-gray-100">
            We provide top-notch services to help you achieve your goals.
          </p>
        </div>

        {/* Quick Links Section */}
        <div className="mb-6 md:mb-0 text-center md:text-left">
          <h2 className="text-xl font-semibold mb-2">Quick Links</h2>
          <ul className="space-y-2">
            <li>
              <a href="#" className="text-gray-100 hover:text-white">
                Home
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-100 hover:text-white">
                Services
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-100 hover:text-white">
                Pricing
              </a>
            </li>
            <li>
              <a href="#" className="text-gray-100 hover:text-white">
                Contact
              </a>
            </li>
          </ul>
        </div>

        {/* Contact Us Section */}
        <div className="text-center md:text-right">
          <h2 className="text-xl font-semibold mb-2">Contact Us</h2>
          <p className="text-gray-100">1234 Main Street, Anytown, USA</p>
          <p className="text-gray-100">Phone: (123) 456-7890</p>
          <p className="text-gray-100">Email: writetokhair@gmail.com</p>
        </div>
      </div>

      {/* Footer Bottom Section */}
      <div className="mt-8 border-t border-gray-100 pt-4 text-center md:text-left">
        <div className="flex flex-wrap justify-center md:justify-start space-x-4 mb-4">
          <a href="#" className="text-gray-100 hover:text-white">
            Facebook
          </a>
          <a href="#" className="text-gray-100 hover:text-white">
            Twitter
          </a>
          <a href="#" className="text-gray-100 hover:text-white">
            LinkedIn
          </a>
          <a href="#" className="text-gray-100 hover:text-white">
            Instagram
          </a>
        </div>
        <p className="text-sm text-gray-200">
          © 2024 YourCompany. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
</div>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Footer02;
