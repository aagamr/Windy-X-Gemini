import React, { useState } from "react";

// Sample image URL for demonstration
const imageUrl = "https://via.placeholder.com/150";

const Footer01 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div role="status" className="flex flex-col w-full">
            <footer class="bg-gray-800 text-white py-6 px-2 rounded-md ">
              <div class="container mx-auto px-4">
                <div class="flex flex-wrap justify-between items-center">
                  <div class="w-full md:w-1/4 text-center md:text-left mb-4 md:mb-0">
                    <a href="#" class="text-2xl font-bold">
                      YourLogo
                    </a>
                  </div>

                  <div class="w-full md:w-1/2 text-center md:text-center mb-4 md:mb-0">
                    <ul class="flex flex-wrap justify-center md:justify-center space-x-4">
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          Home
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          About
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          Services
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          Contact
                        </a>
                      </li>
                    </ul>
                  </div>

                  <div class="w-full md:w-1/4 text-center md:text-right">
                    <ul class="flex justify-center md:justify-end space-x-4">
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          Facebook
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          Twitter
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-400">
                          Instagram
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>

                <div class="text-center mt-6">
                  <p class="text-sm">
                    © 2024 YourCompany. All rights reserved.
                  </p>
                </div>
              </div>
            </footer>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div role="status" className="flex flex-col w-full">
  <footer className="bg-gray-800 text-white py-6 px-2">
    <div className="container mx-auto px-4">
      <div className="flex flex-wrap justify-between items-center">
        {/* Logo */}
        <div className="w-full md:w-1/4 text-center md:text-left mb-4 md:mb-0">
          <a href="#" className="text-2xl font-bold">
            YourLogo
          </a>
        </div>

        {/* Navigation Links */}
        <div className="w-full md:w-1/2 text-center mb-4 md:mb-0">
          <ul className="flex flex-wrap justify-center space-x-4">
            <li>
              <a href="#" className="hover:text-gray-400">
                Home
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-400">
                About
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-400">
                Services
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-400">
                Contact
              </a>
            </li>
          </ul>
        </div>

        {/* Social Media Links */}
        <div className="w-full md:w-1/4 text-center md:text-right">
          <ul className="flex justify-center md:justify-end space-x-4">
            <li>
              <a href="#" className="hover:text-gray-400">
                Facebook
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-400">
                Twitter
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-400">
                Instagram
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="text-center mt-6">
        <p className="text-sm">
          © 2024 YourCompany. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
</div>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Footer01;
