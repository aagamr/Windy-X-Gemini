import React, { useState } from "react";

// Sample image URL for demonstration
const imageUrl = "https://via.placeholder.com/150";

const Footer03 = () => {
  const [activeTab, setActiveTab] = useState("preview");

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="p-4">
      <div className="flex border-b">
        <button
          onClick={() => handleTabChange("preview")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "preview"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Preview
        </button>
        <button
          onClick={() => handleTabChange("code")}
          className={`py-2 px-4 text-sm font-medium ${
            activeTab === "code"
              ? "border-b-2 border-blue-500 text-blue-600"
              : "text-gray-600"
          }`}
        >
          Code
        </button>
      </div>
      {/* Tab content */}
      <div
        className={`${
          activeTab === "preview"
            ? "p-2 md:p-4 lg:p-10 border bg-gray-50 flex min-h-40"
            : "p-0"
        }`}
      >
        {activeTab === "preview" && (
          <div role="status" className="flex flex-col w-full">
            <footer class="bg-white text-gray-700 py-8 rounded-md">
              <div class="container mx-auto px-6">
                <div class="flex flex-col md:flex-row md:justify-between items-center">
                  <div class="mb-6 md:mb-0 text-center md:text-left">
                    <a href="#" class="text-3xl font-bold text-gray-900">
                      WindyUI
                    </a>
                    <p class="text-sm mt-2">
                      Innovative solutions for modern challenges.
                    </p>
                  </div>

                  <div class="mb-6 md:mb-0">
                    <h2 class="text-lg font-semibold mb-4 text-center md:text-left">
                      Explore
                    </h2>
                    <ul class="space-y-2">
                      <li>
                        <a href="#" class="hover:text-gray-900">
                          Home
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-900">
                          About Us
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-900">
                          Services
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-900">
                          Blog
                        </a>
                      </li>
                      <li>
                        <a href="#" class="hover:text-gray-900">
                          Contact
                        </a>
                      </li>
                    </ul>
                  </div>

                  <div class="text-center md:text-right">
                    <h2 class="text-lg font-semibold mb-4">Subscribe</h2>
                    <form
                      action="#"
                      method="post"
                      class="flex flex-col md:flex-row items-center"
                    >
                      <input
                        type="email"
                        placeholder="Your email address"
                        class="px-4 py-2 border border-gray-300 rounded-md mb-2 md:mb-0 md:mr-2"
                        required
                      />
                      <button
                        type="submit"
                        class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                      >
                        Subscribe
                      </button>
                    </form>
                  </div>
                </div>

                <div class="mt-8 border-t border-gray-300 pt-4 text-center">
                  <p class="text-sm text-gray-600">
                    © 2024 BrandName. All rights reserved.
                  </p>
                  <p class="text-xs mt-2 text-gray-500">
                    Designed with ❤️ by YourCompany
                  </p>
                </div>
              </div>
            </footer>
          </div>
        )}
        {activeTab === "code" && (
          <pre className="bg-gray-700 p-4 rounded-md border border-gray-300 w-full overflow-x-auto text-white text-sm ">
            <code>
              {`<div role="status" className="flex flex-col w-full">
  <footer className="bg-white text-gray-700 py-8 rounded-md">
    <div className="container mx-auto px-6">
      <div className="flex flex-col md:flex-row md:justify-between items-start md:items-center">
        {/* Brand Section */}
        <div className="mb-6 md:mb-0 text-center md:text-left">
          <a href="#" className="text-3xl font-bold text-gray-900">
            BrandName
          </a>
          <p className="text-sm mt-2 text-gray-600">
            Innovative solutions for modern challenges.
          </p>
        </div>

        {/* Explore Section */}
        <div className="mb-6 md:mb-0">
          <h2 className="text-lg font-semibold mb-4 text-center md:text-left">
            Explore
          </h2>
          <ul className="space-y-2">
            <li>
              <a href="#" className="hover:text-gray-900">
                Home
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-900">
                About Us
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-900">
                Services
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-900">
                Blog
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-gray-900">
                Contact
              </a>
            </li>
          </ul>
        </div>

        {/* Subscribe Section */}
        <div className="text-center md:text-right">
          <h2 className="text-lg font-semibold mb-4">Subscribe</h2>
          <form
            action="#"
            method="post"
            className="flex flex-col md:flex-row items-center"
          >
            <input
              type="email"
              placeholder="Your email address"
              className="px-4 py-2 border border-gray-300 rounded-md mb-2 md:mb-0 md:mr-2"
              required
            />
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>

      {/* Footer Bottom Section */}
      <div className="mt-8 border-t border-gray-300 pt-4 text-center">
        <p className="text-sm text-gray-600">
          © 2024 BrandName. All rights reserved.
        </p>
        <p className="text-xs mt-2 text-gray-500">
          Designed with ❤️ by YourCompany
        </p>
      </div>
    </div>
  </footer>
</div>
`}
            </code>
          </pre>
        )}
      </div>
    </div>
  );
};

export default Footer03;
