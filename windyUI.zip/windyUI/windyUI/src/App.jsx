import { useState } from "react";

import "./App.css";
import Navbar from "./components/Navbar";
import { Route, Routes } from "react-router-dom";
import Landing from "./screens/Landing";
import Footer from "./components/Footer";
import Spinner from "./feature-components/01. spinner/Spinner";
import Alert from "./feature-components/02. alerts/Alert";
import Button from "./feature-components/03. button/Button";
import NavbarC from "./feature-components/04. navbar/NavbarC";
import FooterC from "./feature-components/05. footer/FooterC";
import Accordian from "./feature-components/06. accordian/Accordian";
import HeroSectionC from "./feature-components/07. hero/HeroSectionC";
import FAQ from "./screens/FAQ";
import Playground from "./screens/Playground";
import Cards from "./feature-components/08. cards/Cards";

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route element={<Landing />} path="/" />
        <Route element={<FAQ />} path="/faq" />
        <Route element={<Playground />} path="/lab" />

        {/* components */}
        <Route element={<Spinner />} path="/components/spinners" />
        <Route element={<Alert />} path="/components/alerts" />
        <Route element={<Button />} path="/components/buttons" />
        <Route element={<NavbarC />} path="/components/navbars" />

        <Route element={<FooterC />} path="/components/footers" />
        <Route element={<Accordian />} path="/components/accordians" />
        <Route element={<HeroSectionC />} path="/components/heros" />
        <Route element={<Cards />} path="/components/cards" />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
